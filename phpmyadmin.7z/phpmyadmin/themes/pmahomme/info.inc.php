<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * Theme information
 *
 * @package    PhpMyAdmin-theme
 * @subpackage PMAHomme
 */

/**
 * If you have problems or questions about this theme email
 * mikehomme@users.sourceforge.net
 */
$theme_name = 'pmahomme';
$theme_full_version = '1.1';
?>
